CryptoBay Pro 4.3.0
====================

1. Установи зависимости:
   pip install -r requirements.txt

2. Запуск менеджера:
   python CryptoBay_Bot_Manager.py

3. В файле .env укажи реальный BOT_TOKEN от BotFather.

Этот проект использует CoinGecko API для курсов и графика.

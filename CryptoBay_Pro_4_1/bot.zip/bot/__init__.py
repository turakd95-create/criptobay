# Package init for CryptoBay bot

import asyncio
import logging
import os
from pathlib import Path
from typing import Optional, Dict, Any, List

import requests
from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import CommandStart
from aiogram.types import (
    Message,
    ReplyKeyboardMarkup,
    KeyboardButton,
    FSInputFile,
)
from dotenv import load_dotenv

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from datetime import datetime

# === ПУТИ И .ENV ===

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_PATH = BASE_DIR / ".env"

print(f"ENV файл: {ENV_PATH}")
if ENV_PATH.exists():
    load_dotenv(dotenv_path=ENV_PATH)
else:
    print("ВНИМАНИЕ: .env не найден!")

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID_STR = os.getenv("ADMIN_TELEGRAM_ID", "").strip()
ADMIN_ID = int(ADMIN_ID_STR) if ADMIN_ID_STR.isdigit() else None
COINGECKO_API_KEY = (os.getenv("COINGECKO_API_KEY") or "").strip()

if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN не найден в .env. Проверь файл .env")


# === ЛОГИ ===

LOG_FILE = BASE_DIR / "bot.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("cryptobay.bot")
logger.info("Запуск CryptoBay бота…")


# === НАСТРОЙКИ COINGECKO ===

CG_BASE = "https://api.coingecko.com/api/v3"


def cg_headers() -> Dict[str, str]:
    """
    Заголовки для CoinGecko.
    Если COINGECKO_API_KEY не задан, работаем в публичном режиме.
    """
    if COINGECKO_API_KEY:
        return {"x-cg-demo-api-key": COINGECKO_API_KEY}
    return {}


# === ФУНКЦИИ ДЛЯ ПОЛУЧЕНИЯ ДАННЫХ ===

def get_btc_price() -> Optional[Dict[str, Any]]:
    """
    Текущая цена BTC + капитализация + объём + изменение за 24ч.
    """
    url = f"{CG_BASE}/simple/price"
    params = {
        "ids": "bitcoin",
        "vs_currencies": "usd",
        "include_market_cap": "true",
        "include_24hr_vol": "true",
        "include_24hr_change": "true",
    }
    r = requests.get(url, params=params, headers=cg_headers(), timeout=20)
    r.raise_for_status()
    data = r.json().get("bitcoin")
    return data


def get_top10() -> List[Dict[str, Any]]:
    """
    Топ-10 монет по капитализации.
    """
    url = f"{CG_BASE}/coins/markets"
    params = {
        "vs_currency": "usd",
        "order": "market_cap_desc",
        "per_page": 10,
        "page": 1,
        "price_change_percentage": "24h",
    }
    r = requests.get(url, params=params, headers=cg_headers(), timeout=25)
    r.raise_for_status()
    return r.json()


def build_btc_chart_png(days: int = 7) -> Optional[Path]:
    """
    График BTC за N дней. Если CoinGecko отдаёт 401 — возвращаем None.
    """
    url = f"{CG_BASE}/coins/bitcoin/market_chart"
    params = {
        "vs_currency": "usd",
        "days": days,
        "interval": "hourly",
    }
    r = requests.get(url, params=params, headers=cg_headers(), timeout=25)
    if r.status_code == 401:
        logger.error("CoinGecko вернул 401 Unauthorized при запросе графика")
        return None

    r.raise_for_status()
    data = r.json()
    prices = data.get("prices", [])
    if not prices:
        return None

    ts = [p[0] / 1000 for p in prices]
    vs = [p[1] for p in prices]
    times = [datetime.fromtimestamp(t) for t in ts]

    plt.figure(figsize=(8, 4))
    plt.plot(times, vs)
    plt.xlabel("Время")
    plt.ylabel("Цена, USD")
    plt.title("Bitcoin — последние 7 дней")
    plt.grid(True, linestyle="--", linewidth=0.5)
    plt.tight_layout()

    charts_dir = BASE_DIR / "charts"
    charts_dir.mkdir(exist_ok=True)
    out_path = charts_dir / "btc_last7d.png"
    plt.savefig(out_path)
    plt.close()

    return out_path


# === КЛАВИАТУРА ===

main_menu_kb = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="📊 Курсы"),
            KeyboardButton(text="📉 Топ-10"),
        ],
        [
            KeyboardButton(text="📈 График BTC"),
            KeyboardButton(text="🔔 Уведомления"),
        ],
        [
            KeyboardButton(text="💱 Купить / продать"),
            KeyboardButton(text="☎ Поддержка"),
        ],
    ],
    resize_keyboard=True,
)


# === СОСТОЯНИЕ ДЛЯ УВЕДОМЛЕНИЙ ===

alerts_enabled: bool = False
watch_last_price: Optional[float] = None


# === РОУТЕР И ХЕНДЛЕРЫ ===

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    logger.info("Старт от пользователя %s", message.from_user.id)
    await message.answer(
        "👋 Привет! Это CryptoBay.\n\n"
        "Я могу показать курсы, топ-10 монет, график BTC "
        "и отправлять авто-уведомления об изменении цены.\n\n"
        "Выбери действие на клавиатуре ниже 👇",
        reply_markup=main_menu_kb,
    )


@router.message(F.text == "📊 Курсы")
async def handle_rates(message: Message):
    logger.info("Курсы запрошены пользователем %s", message.from_user.id)
    try:
        data = await asyncio.to_thread(get_btc_price)
        if not data:
            raise RuntimeError("Пустой ответ от CoinGecko")

        price = data.get("usd")
        mcap = data.get("usd_market_cap")
        vol = data.get("usd_24h_vol")
        change = data.get("usd_24h_change")

        def fmt_num(x: Optional[float]) -> str:
            if x is None:
                return "—"
            return f"{x:,.0f}".replace(",", " ")

        def fmt_change(x: Optional[float]) -> str:
            if x is None:
                return "—"
            sign = "🔺" if x >= 0 else "🔻"
            return f"{sign} {x:.2f} %"

        text = (
            "💰 *Bitcoin (BTC)*\n\n"
            f"Текущая цена: *{fmt_num(price)} $*\n"
            f"Рыночная капитализация: *{fmt_num(mcap)} $*\n"
            f"Объём за 24ч: *{fmt_num(vol)} $*\n"
            f"Изменение за 24ч: *{fmt_change(change)}*"
        )

        await message.answer(text, parse_mode="Markdown")
    except Exception as e:
        logger.exception("Ошибка запроса курсов: %s", e)
        await message.answer(
            "❌ Не удалось получить курсы.\n"
            "Попробуй ещё раз чуть позже."
        )


@router.message(F.text == "📉 Топ-10")
async def handle_top10(message: Message):
    logger.info("Топ-10 запрошен пользователем %s", message.from_user.id)
    try:
        data = await asyncio.to_thread(get_top10)
        if not data:
            raise RuntimeError("Пустой ответ от CoinGecko")

        lines = ["📉 *Топ-10 монет по капитализации* (USD):\n"]
        for i, coin in enumerate(data, start=1):
            name = coin.get("name")
            symbol = coin.get("symbol", "").upper()
            price = coin.get("current_price")
            mcap = coin.get("market_cap")
            vol = coin.get("total_volume")
            change = coin.get("price_change_percentage_24h")

            def fmt_num(x: Optional[float]) -> str:
                if x is None:
                    return "—"
                return f"{x:,.0f}".replace(",", " ")

            ch_str = "—"
            if change is not None:
                sign = "🔺" if change >= 0 else "🔻"
                ch_str = f"{sign} {change:.2f} %"

            lines.append(
                f"*{i}. {name} ({symbol})*\n"
                f"   Цена: {fmt_num(price)} $\n"
                f"   Капитализация: {fmt_num(mcap)} $\n"
                f"   Объём 24ч: {fmt_num(vol)} $\n"
                f"   Изм. 24ч: {ch_str}\n"
            )

        await message.answer("\n".join(lines), parse_mode="Markdown")
    except Exception as e:
        logger.exception("Ошибка запроса топ-10: %s", e)
        await message.answer(
            "❌ Не удалось получить топ-10 монет.\n"
            "Возможно, CoinGecko временно недоступен."
        )


@router.message(F.text == "📈 График BTC")
async def handle_chart(message: Message):
    logger.info("График запрошен пользователем %s", message.from_user.id)
    try:
        path = await asyncio.to_thread(build_btc_chart_png)
        if not path:
            await message.answer(
                "⚠ График временно недоступен (ограничение CoinGecko).\n"
                "Но курсы и топ-10 продолжают работать."
            )
            return

        photo = FSInputFile(path)
        await message.answer_photo(
            photo,
            caption="📈 График Bitcoin за последние 7 дней (USD)",
        )
    except Exception as e:
        logger.exception("Ошибка построения графика: %s", e)
        await message.answer(
            "❌ Не удалось построить график.\n"
            "Попробуй ещё раз позже."
        )


@router.message(F.text == "💱 Купить / продать")
async def handle_trade(message: Message):
    logger.info("Купить/продать от %s", message.from_user.id)
    await message.answer(
        "💱 Раздел покупки / продажи пока в разработке.\n\n"
        "Если хочешь подключить свой обменник или поток заявок — "
        "напиши админу, и мы интегрируем это сюда."
    )


@router.message(F.text == "☎ Поддержка")
async def handle_support(message: Message):
    logger.info("Поддержка запрошена пользователем %s", message.from_user.id)
    text = (
        "☎ *Поддержка CryptoBay*\n\n"
        "По любым вопросам напиши админу в Telegram.\n"
        "Сейчас установлен ID администратора из .env:\n"
        f"`{ADMIN_ID}`\n\n"
        "Можешь заменить этот текст на свой @username в коде."
    )
    await message.answer(text, parse_mode="Markdown")


@router.message(F.text == "🔔 Уведомления")
async def handle_alerts(message: Message):
    global alerts_enabled
    alerts_enabled = not alerts_enabled

    if alerts_enabled:
        logger.info("Уведомления включены пользователем %s", message.from_user.id)
        await message.answer(
            "🔔 Авто-уведомления по BTC включены.\n"
            "Я напишу, если цена изменится более чем на 2% за ~5 минут."
        )
    else:
        logger.info("Уведомления выключены пользователем %s", message.from_user.id)
        await message.answer("🔕 Авто-уведомления выключены.")


@router.message()
async def fallback(message: Message):
    await message.answer(
        "Я тебя понял, но пока работаю по кнопкам 😊\n"
        "Выбери действие на клавиатуре ниже 👇",
        reply_markup=main_menu_kb,
    )


# === ФОНОВЫЙ ВОТЧЕР ЦЕН ===

async def price_watcher(bot: Bot):
    """
    Фоновая задача: раз в 5 минут смотрит цену BTC.
    Если включены уведомления и изменение > 2% — шлёт сообщение админу.
    """
    global watch_last_price
    logger.info("Запуск фонового наблюдателя цен")
    while True:
        try:
            data = await asyncio.to_thread(get_btc_price)
            if not data:
                await asyncio.sleep(300)
                continue

            price = data.get("usd")
            if price is None:
                await asyncio.sleep(300)
                continue

            if alerts_enabled and ADMIN_ID:
                if watch_last_price:
                    diff = (price - watch_last_price) / watch_last_price * 100
                    if abs(diff) >= 2:
                        text = (
                            f"🔔 BTC изменился на {diff:+.2f} %\n"
                            f"Текущая цена: {price:,.0f} $"
                        ).replace(",", " ")
                        await bot.send_message(ADMIN_ID, text)
                        logger.info("Уведомление отправлено админу %s", ADMIN_ID)
                watch_last_price = price

        except Exception as e:
            logger.error("Ошибка в price_watcher: %s", e)

        await asyncio.sleep(300)


# === ЗАПУСК БОТА ===

async def main():
    bot = Bot(token=BOT_TOKEN)
    dp = Dispatcher()
    dp.include_router(router)

    # фоновая задача
    asyncio.create_task(price_watcher(bot))

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
